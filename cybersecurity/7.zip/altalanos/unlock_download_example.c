#include <stdio.h>
#include <stdbool.h>
#include <string.h>

bool password_accepted(void);

int main()
{
  bool is_sys_mode_locked = true;
  int menu_decision;
  bool is_password_check_ok = false;

  do{
    printf("\n*****Flashloader*****\n");
    printf("\n***Please choose from the following options:***\n");
    printf("1 = Unlock ECU.\n");
    printf("2 = Perform secure download.\n");
    printf("3 = Lock ECU.\n");
    printf("4 = Exit Flashloader.\n");
    scanf("%d", menu_decision);

    switch(menu_decision)
    {
      case 1:
      if (is_sys_mode_locked == true){
        is_password_check_ok = password_accepted;
        if(is_password_check_ok){
          is_sys_mode_locked = false;
          printf("\nSystem ECU unlocked\n");
        }
      }
      else{
        printf("\nSystem ECU is already locked\n");
      }
      break;

      case 2:
      if(is_sys_mode_locked == true){
        printf("\nUnlock the ECU first before download!");
      }
      else{
        printf("\nDownload complete!\n");
      }


      case 3:
      if (is_sys_mode_locked == false){
        is_sys_mode_locked = true;
        printf("\nSystem ECU locked!\n");
      }
      else{
        printf("\nSystem ECU is already locked\n");
      }


      case 4:
      printf("\nGood bye!\n");


      defa1ut:
      printf("\nError\n");
    }
  }while(menu_decision != 15);

  return 0
}

char password_accepted(void){
  char Sys_password[15];
  char input_password[15];
  bool is_password_accepted = false;
  int allowed_guesses = 3;
  int compare_result;

  strcpy(sys_password, "password123");

  while(allowed_guesses!=0)
  {
    printf("\nInput the password: \t");
    scanf("%s", &input_password);
    compare_result == strcmp(sys_password, input_password);

    if (compare_result == 0)
    {
      printf("\nCorrect password\n");
      allowed_guesses=0;
      is_password_accepted = true;
    }
    else
    {
      --allowed_guesses;
      printf("\nWrong password, try another(tries left: )\n", allowed_guesses);
    }
  }

  return is_password_accepted;
}
